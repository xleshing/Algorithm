%% 參數設定
L = 100;               % 區域長度 (公里)
W = 100;               % 區域寬度 (公里)
numEdgeNodes = 20;     % 目標 Edge Node 數量
numRandomPoints = 1000; % 用於 k-means 的隨機點數（越多越均勻）
coverageRadius = 20;   % 每個 Edge Node 的覆蓋半徑 (公里)
devicesPerNode = 10;   % 每個 Edge Node 連接的設備數量

% VNF 設定：假設有 3 種 VNF 型別，機率分布如下：
vnfTypes = [1, 2, 3];      % VNF 型別編號
vnfProbabilities = [0.5, 0.3, 0.2]; % 各型別機率
% 可根據需要調整每個基地台的 VNF 總數量，這裡以 [2, 5] 範圍內隨機決定
minVNF = 2;
maxVNF = 5;

%% Step 1：生成隨機點並利用 k-means 調整 Edge Node 分布
% 生成 numRandomPoints 個在 [0,L] x [0,W] 內均勻隨機點
points = [L*rand(numRandomPoints,1), W*rand(numRandomPoints,1)];

% 利用 k-means 分群，分成 numEdgeNodes 個群組
% 'Replicates' 可設定多次重啟以獲得更穩定結果
[idx, centroids] = kmeans(points, numEdgeNodes, 5);

% centroids 為各群集中心，作為 Edge Node 的位置
edgeNodePositions = centroids; 

%% Step 2：對每個 Edge Node 連線（僅連線範圍內最近的鄰居）
edges = []; % 儲存連線對，格式為 [node1, node2]
numNodes = size(edgeNodePositions,1);
for i = 1:numNodes
    currentPos = edgeNodePositions(i,:);
    % 計算與其他節點的距離
    distances = sqrt(sum((edgeNodePositions - currentPos).^2, 2));
    distances(i) = inf; % 自己排除掉
    % 找出落在覆蓋範圍內的節點
    inRangeIdx = find(distances <= coverageRadius);
    if ~isempty(inRangeIdx)
        % 從中選取距離最近的節點
        [~, minIdx] = min(distances(inRangeIdx));
        nearestNode = inRangeIdx(minIdx);
        % 為避免重複連線（或雙向連線可視需求而定），只加入一次
        if i < nearestNode
            edges = [edges; i, nearestNode];
        end
    end
end

%% Step 3：對每個 Edge Node 分配 VNF
% 建立一個 cell array 用於儲存每個 Node 的 VNF 設定
edgeNodeVNF = cell(numNodes,1);
for i = 1:numNodes
    % 決定該 Node 內 VNF 的數量（在 minVNF ~ maxVNF 間隨機）
    numVNFs = randi([minVNF, maxVNF]);
    vnfList = zeros(numVNFs,1);
    for j = 1:numVNFs
        % 根據 PDF 隨機選取 VNF 型別
        r = rand;
        cumulativeProb = cumsum(vnfProbabilities);
        vnfType = vnfTypes(find(r <= cumulativeProb, 1, 'first'));
        vnfList(j) = vnfType;
    end
    edgeNodeVNF{i} = vnfList;
end

%% Step 4：在每個 Edge Node 下生成並連接 Devices
% 建立 cell array 儲存各 Edge Node 下設備的座標
edgeNodeDevices = cell(numNodes,1);
for i = 1:numNodes
    devices = zeros(devicesPerNode,2);
    % 以極座標方法生成設備在基地台覆蓋圓內的均勻分布
    for d = 1:devicesPerNode
        theta = 2*pi*rand;           % 角度
        r = coverageRadius * sqrt(rand); % 半徑（開根號使分布均勻）
        % 轉換成直角座標，相對於 Edge Node 位置
        devices(d,1) = edgeNodePositions(i,1) + r*cos(theta);
        devices(d,2) = edgeNodePositions(i,2) + r*sin(theta);
    end
    edgeNodeDevices{i} = devices;
end

%% Step 5：繪圖
figure;
hold on;
grid on;
axis([0 L 0 W]);
title('Edge Nodes 與 Devices 模擬圖');
xlabel('X (公里)');
ylabel('Y (公里)');

% 繪製區域邊界
rectangle('Position',[0,0,L,W],'EdgeColor','k','LineWidth',1.5);

% 繪製 Edge Node（基地台），使用紅色圓點標示
scatter(edgeNodePositions(:,1), edgeNodePositions(:,2), 100, 'r', 'filled');

% 繪製 Edge Node 之間的連線（黑線）
for k = 1:size(edges,1)
    node1 = edges(k,1);
    node2 = edges(k,2);
    pos1 = edgeNodePositions(node1,:);
    pos2 = edgeNodePositions(node2,:);
    plot([pos1(1) pos2(1)], [pos1(2) pos2(2)], 'k-', 'LineWidth', 1);
end

% 繪製每個 Edge Node 下的 Devices，並用虛線連接到 Edge Node
for i = 1:numNodes
    devices = edgeNodeDevices{i};
    % 用藍色小點表示設備
    scatter(devices(:,1), devices(:,2), 30, 'b', 'filled');
    % 從基地台位置連接到每個設備
    for d = 1:size(devices,1)
        plot([edgeNodePositions(i,1), devices(d,1)], ...
             [edgeNodePositions(i,2), devices(d,2)], 'b--');
    end
end

hold off;

%% 額外：在 Command Window 輸出每個 Edge Node 的 VNF 配置
for i = 1:numNodes
    fprintf('Edge Node %d: VNF 型別配置 -> %s\n', i, mat2str(edgeNodeVNF{i}));
end
